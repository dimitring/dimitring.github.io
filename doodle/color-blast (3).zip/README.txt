A Pen created at CodePen.io. You can find this one at http://codepen.io/dimitring/pen/BybPPM.

 Use the `Left` and `Right` Arrows or `A` and `D` keys to move, `Spacebar` to shoot.

Game starts right away, looks best in [full mode.](http://codepen.io/natewiley/full/EGyiF) 

Hope you like it! ;)

Forked from [Nate Wiley](http://codepen.io/natewiley/)'s Pen [Color Blast!](http://codepen.io/natewiley/pen/EGyiF/).

Forked from [Nate Wiley](http://codepen.io/natewiley/)'s Pen [Color Blast!](http://codepen.io/natewiley/pen/EGyiF/).